<?php
Configure::write('CakePluginTest.test_plugin.custom', 'loaded plugin custom config');