<?php

App::uses('CakeRoute', 'Routing/Route');

class TestRoute extends CakeRoute {

}
