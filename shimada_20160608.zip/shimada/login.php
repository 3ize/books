<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>ログイン</title>
</head>
<body>
<h1>ログイン</h1>
<p><a href="redirect.php">Googleアカウントでログインする</a></p>
</body>
</html>
<br>
<br>
<br>



<p><input id="txt150719" size="" type="text" value="" /><input id="token_get_all" type="button" value="ログイン" /></p>
「Googleアカウントでログインする」ボタン