<?php

echo "test";

あ
あいうえお

?>
